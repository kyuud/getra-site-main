<div class="section-header">
    <h2 class="section-title text-center wow fadeInDown" style="margin: 25px">Instagram</h2>
    <p class="text-center wow fadeInDown"> <a href="https://www.instagram.com/getragestao/">Siga-nos no instagram</a></p>
</div>
    
    <!-- The target container for the images -->
    <div id="instafeed"></div>
    
    <!-- The Token Agent service - make sure to use your own URL here -->
    <script src="{{url('Site/js/token.js')}}"></script>
    
    <!-- The Instafeed.js library (Don't use this URL in production!) -->
    <script src="{{url('Site/js/instafeed.min.js')}}"></script>

    <!-- Configure and run instafeed -->
    <script src="{{url('Site/js/configinstafeed.js')}}"></script>

    <!-- Some very basic styles to make things look sensible - you don't need to use these -->
    <link rel="stylesheet" href="{{url('Site/css/instafeed.css')}}">